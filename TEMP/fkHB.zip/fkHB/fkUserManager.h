@interface fkUserManager : NSObject

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *uid;
@property (nonatomic, copy) NSString *phone;
@property (nonatomic, copy) NSString *token;

- (fkUserManager *)shared;
+ (BOOL)isLogin;

@end
