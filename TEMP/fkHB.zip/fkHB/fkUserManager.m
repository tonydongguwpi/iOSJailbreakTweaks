#import "fkUserManager.h"
#import <Foundation/Foundation.h>

static NSString* kUserTokenKey = @"userTokenKey";

@implementation fkUserManager : NSObject

- (fkUserManager *)shared {
	static fkUserManager *sharedInstance = nil;  
    static dispatch_once_t once;  
    dispatch_once(&once, ^{  
        sharedInstance = [[fkUserManager alloc] init];  
    });  
    return sharedInstance;
}

+ (BOOL)isLogin {
	return [[[NSUserDefaults standardUserDefaults] objectForKey:kUserTokenKey] length];
}

@end