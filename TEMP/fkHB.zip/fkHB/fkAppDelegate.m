#import "fkAppDelegate.h"
#import "fkLoginViewController.h"
#import "fkUserManager.h"

@interface fkAppDelegate()
@property (nonatomic, retain) UINavigationController *signInViewController;
@end

@implementation fkAppDelegate

- (void)applicationDidFinishLaunching:(UIApplication *)application {
	_window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
	if (![fkUserManager isLogin]) {
		_signInViewController = [[UINavigationController alloc] initWithRootViewController:[[fkLoginViewController alloc] init]];
		_window.rootViewController = _signInViewController;
	}
	[_window makeKeyAndVisible];
}

@end
